import static org.junit.Assert.assertTrue;

import java.util.ArrayList;

import org.junit.Test;

public class TestPattern {

    @Test
    public void testConstructor() {
        Pattern<String> p = new Pattern<>("dog", "o");
        ArrayList<String> expected = new ArrayList<>();
        expected.add(0, "-");
        expected.add(1, "o");
        expected.add(2, "-");
        assertTrue(p.equals(expected));
    }

    // okay, I learned that breaks break you out of loops

    // okay, I learned that addAll doesn't clear c
    // but addAll does alias...damn.
    @Test
    public void testAddAll() {
        ArrayList<StringBuilder> a1 = new ArrayList<>();
        ArrayList<StringBuilder> a2 = new ArrayList<>();

        a1.add(new StringBuilder("a"));
        a1.add(new StringBuilder("b"));
        a1.add(new StringBuilder("c"));

        a2.add(new StringBuilder("1"));
        a2.add(new StringBuilder("2"));
        a2.add(new StringBuilder("3"));

        System.out.println(a1);
        System.out.println(a2);
        System.out.println();

        a2.addAll(a1);

        System.out.println(a1);
        System.out.println(a2);
        System.out.println();

        a1.get(0).append('1');

        System.out.println(a1);
        System.out.println(a2);
        System.out.println();
    }
}
