import java.util.Scanner;

import org.junit.Test;

public class TestController {

    private final static String LETTERS = "abcdefghijklmnopqrstuvwxyz";

    private static int promptNumLetters(Controller controller,
            Scanner consoleIn) {
        System.out.println("How many letters should the word have? : ");
        int wordLength = consoleIn.nextInt();
        consoleIn.nextLine(); // destroy \n
        while (!controller.isValidWordLength(wordLength)) {
            System.out.println("Invalid word length. Enter another number: ");
            wordLength = consoleIn.nextInt();
            consoleIn.nextLine(); // destroy \n
        }
        System.out.println("Great choice!");
        return wordLength;
    }

    private static int promptNumGuesses(Scanner consoleIn) {
        System.out.println("How many guesses would you like? :");
        int numGuesses = consoleIn.nextInt();
        consoleIn.nextLine(); // destroy \n
        while (numGuesses < 1) {
            System.out.println(
                    "Invalid number of guesses. Enter a positive, nonzero number: ");
            numGuesses = consoleIn.nextInt();
            consoleIn.nextLine(); // destroy \n
        }
        System.out.println("Okay, good.");
        return numGuesses;
    }

    private static void gameTurn(Controller controller, Scanner consoleIn,
            Pattern<String> displayedWord, int numGuessesMade,
            int maxNumGuesses, int numLetters) {
        displayGameState(controller, displayedWord, numGuessesMade,
                maxNumGuesses);
        String chosenLetter = promptLetterChoice(controller, consoleIn);
        controller.update(numLetters, chosenLetter);
    }

    private static void displayGameState(Controller controller,
            Pattern<String> displayedWord, int numGuessesMade,
            int maxNumGuesses) {
        System.out.println("You have " + (maxNumGuesses - numGuessesMade)
                + " guesses left.");
        System.out.println(
                "Chosen letters include: " + controller.getChosenLetters());

        System.out.println("The word is " + displayedWord);
        System.out.println();
    }

    private static String promptLetterChoice(Controller controller,
            Scanner consoleIn) {
        System.out.println("Please choose a letter: ");
        String letter = consoleIn.nextLine().toLowerCase();
        while (!isValidLetter(controller, letter)) { //
            System.out.println(
                    "That is not a valid letter. Choose one letter that hasn't already been chosen: ");
            letter = consoleIn.nextLine().toLowerCase();
        }
        System.out.println();
        return letter;
    }

    private static boolean isValidLetter(Controller controller, String s) {
        return !controller.getChosenLetters().contains(s)
                && LETTERS.contains(s);
    }

    @Test
    public void testUpdateWords() {
        Controller controller = new Controller("lib/Words.txt");
        Scanner consoleIn = new Scanner(System.in);

        int numLetters = promptNumLetters(controller, consoleIn);
        controller.setDisplayedPattern(numLetters);
        controller.initializePossibleWords(numLetters);
        int maxNumGuesses = promptNumGuesses(consoleIn);
        int numGuessesMade = 0;

        System.out.println(controller.getChosenLetters());
        System.out.println(controller.getPossibleWords());
        System.out.println(controller.getDisplayedPattern());

        gameTurn(controller, consoleIn, controller.getDisplayedPattern(),
                numGuessesMade, maxNumGuesses, numLetters);

        System.out.println();
        System.out.println(controller.getChosenLetters());
        System.out.println(controller.getPossibleWords());
        System.out.println(controller.getDisplayedPattern());
    }

}
