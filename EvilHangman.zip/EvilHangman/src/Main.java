import java.util.Scanner;

public class Main {

    private final static String LETTERS = "abcdefghijklmnopqrstuvwxyz";

    public static void main(String[] args) {
        Controller controller = new Controller("lib/Words.txt");
        Scanner consoleIn = new Scanner(System.in);

        int numLetters = promptNumLetters(controller, consoleIn);
        controller.setDisplayedPattern(numLetters);
        controller.initializePossibleWords(numLetters);
        int maxNumGuesses = promptNumGuesses(consoleIn);
        int numGuessesMade = 0;

        boolean wonGame = false;
        while (!wonGame && (numGuessesMade < maxNumGuesses)) {
            gameTurn(controller, consoleIn, controller.getDisplayedPattern(),
                    numGuessesMade, maxNumGuesses, numLetters);
            numGuessesMade++;
            wonGame = checkWinCondition(controller);
        }
        displayGameState(controller, controller.getDisplayedPattern(),
                numGuessesMade, maxNumGuesses);
        if (wonGame) {
            System.out.println("Congrats, you won!");
        } else {
            System.out.println("Game Over, you lose.");
        }
        System.out.println(
                "The word was: " + controller.getPossibleWords().get(0));
        // print: "The word was _________." firstWord in possibleWordsList

        //System.out.println("All possible words left are: "
        //        + controller.getPossibleWords());

    }

    private static boolean checkWinCondition(Controller controller) {
        return controller.getPossibleWords()
                .contains(controller.getDisplayedPattern().toString());
    }

    private static void gameTurn(Controller controller, Scanner consoleIn,
            Pattern<String> displayedWord, int numGuessesMade,
            int maxNumGuesses, int numLetters) {
        displayGameState(controller, displayedWord, numGuessesMade,
                maxNumGuesses);
        String chosenLetter = promptLetterChoice(controller, consoleIn);
        controller.update(numLetters, chosenLetter);
    }

    private static void displayGameState(Controller controller,
            Pattern<String> displayedWord, int numGuessesMade,
            int maxNumGuesses) {
        System.out.println("You have " + (maxNumGuesses - numGuessesMade)
                + " guesses left.");
        System.out.println(
                "Chosen letters include: " + controller.getChosenLetters());

        System.out.println("The word is " + displayedWord);
        System.out.println();

        //System.out.println(
        //        "All possible words are: " + controller.getPossibleWords()); // TODO: remove when finished
    }

    private static String promptLetterChoice(Controller controller,
            Scanner consoleIn) {
        System.out.println("Please choose a letter: ");
        String letter = consoleIn.nextLine().toLowerCase();
        while (!isValidLetter(controller, letter)) { //
            System.out.println(
                    "That is not a valid letter. Choose one letter that hasn't already been chosen: ");
            letter = consoleIn.nextLine().toLowerCase();
        }
        System.out.println();
        return letter;
    }

    private static int promptNumLetters(Controller controller,
            Scanner consoleIn) {
        System.out.println("How many letters should the word have? : ");
        int wordLength = consoleIn.nextInt();
        consoleIn.nextLine(); // destroy \n
        while (!controller.isValidWordLength(wordLength)) {
            System.out.println("Invalid word length. Enter another number: ");
            wordLength = consoleIn.nextInt();
            consoleIn.nextLine(); // destroy \n
        }
        System.out.println("Great choice!");
        return wordLength;
    }

    private static int promptNumGuesses(Scanner consoleIn) {
        System.out.println("How many guesses would you like? :");
        int numGuesses = consoleIn.nextInt();
        consoleIn.nextLine(); // destroy \n
        while (numGuesses < 1) {
            System.out.println(
                    "Invalid number of guesses. Enter a positive, nonzero number: ");
            numGuesses = consoleIn.nextInt();
            consoleIn.nextLine(); // destroy \n
        }
        System.out.println("Okay, good.");
        return numGuesses;
    }

    private static boolean isValidLetter(Controller controller, String s) {
        return !controller.getChosenLetters().contains(s)
                && LETTERS.contains(s);
    }
}
