import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;

public class Pattern<T> extends ArrayList<String> {

    public Pattern() {
        super();
    }

    public Pattern(Collection<String> c) {
        super(c);
    }

    public Pattern(int numLetters) {
        super(Arrays.asList(new String[numLetters]));
        Collections.fill(this, "-");
    }

    public Pattern(String word, String chosenLetter) {
        super();
        for (int i = 0; i < word.length(); i++) {
            String element = "-";
            if (chosenLetter.equals(Character.toString(word.charAt(i)))) { // BUG?
                element = chosenLetter;
            }
            this.add(i, element);
        }
    }

    @Override
    public java.lang.String toString() {
        java.lang.String word = "";
        for (int i = 0; i < this.size(); i++) {
            word += this.get(i);
        }
        return word;
    }

    public boolean equals(ArrayList<String> word) {
        if (word.size() != this.size()) {
            return false;
        }
        for (int i = 0; i < this.size(); i++) {
            if (!word.get(i).equals(this.get(i))) {
                return false;
            }
        }
        return true;
    }
}
