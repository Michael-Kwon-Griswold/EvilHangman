import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Controller {
    private final static String LETTERS = "abcdefghijklmnopqrstuvwxyz";

    private Scanner fileIn;
    private ArrayList<String> possibleWords;
    private Pattern<String> displayedPattern;
    private ArrayList<String> chosenLetters;

    public Controller(String fileName) {
        File file = new File(fileName);
        try {
            this.fileIn = new Scanner(file);
        } catch (FileNotFoundException e) {
            System.err.println("File not found");
        }
        this.chosenLetters = new ArrayList<>();
        this.possibleWords = this.tokenizeFromFile();
    }

    public void setDisplayedPattern(int numLetters) {
        this.displayedPattern = new Pattern<>(numLetters);
    }

    public Pattern<String> getDisplayedPattern() {
        return this.displayedPattern;
    }

    public ArrayList<String> getPossibleWords() {
        return this.possibleWords;
    }

    public ArrayList<String> getChosenLetters() {
        return this.chosenLetters;
    }

    // reads from file, using in to update an ArrayList of tokenized words
    private ArrayList<String> tokenizeFromFile() {
        ArrayList<String> words = new ArrayList<>();
        while (this.fileIn.hasNextLine()) {
            words.add(this.fileIn.nextLine());
        }
        return words;
    }

    public void update(int numLetters, String chosenLetter) {
        this.chosenLetters.add(chosenLetter);
        this.updatePossibleWords(numLetters, chosenLetter);
    }

    public void initializePossibleWords(int numLetters) {
        this.possibleWords
                .removeIf((String word) -> word.length() != numLetters);
    }

    public void updatePossibleWords(int numLetters, String chosenLetter) {
        boolean letterPresent = false;
        for (String word : this.possibleWords) {
            if (word.contains(chosenLetter)) {
                letterPresent = true;
                break;
            }
        }

        if (letterPresent) {
            ArrayList<WordFamily<String>> wordFamilies = new ArrayList<>();

            // separate possible words into families of words
            for (String word : this.possibleWords) {
                Pattern<String> pattern = this.fabricatePattern(word,
                        chosenLetter); // this is why it resets. need a constructor with parameter currentPattern
                boolean novelPattern = true;
                for (WordFamily<String> family : wordFamilies) {
                    if (family.patternMatches(pattern)) {
                        novelPattern = false;
                        family.add(word);
                    }
                }
                if (novelPattern) {
                    wordFamilies.add(0, new WordFamily<String>(pattern)); // pattern not found in current families, add new family
                    wordFamilies.get(0).add(word);
                }
            }

            // possibleWords = largestFamily
            WordFamily<String> chosenFamily = this.largestFamily(wordFamilies);
            this.possibleWords.clear();
            this.possibleWords.addAll(chosenFamily);
            this.updateDisplayedPattern(chosenFamily);
        }

    }

    private Pattern<String> fabricatePattern(String word, String chosenLetter) {
        if (this.displayedPattern.equals(new Pattern<>())) {
            return new Pattern<>(word, chosenLetter);
        }
        Pattern<String> newPattern = new Pattern<>(this.displayedPattern);

        for (int i = 0; i < word.length(); i++) {
            if (newPattern.get(i).equals("-") && Character
                    .toString(word.charAt(i)).equals(chosenLetter)) {
                newPattern.set(i, chosenLetter);
            }
        }
        return newPattern;
    }

    private static boolean isLetter(String s) {
        return LETTERS.contains(s);
    }

    private WordFamily<String> largestFamily(
            ArrayList<WordFamily<String>> wordFamilies) {
        WordFamily<String> largestFamily = wordFamilies.get(0);
        for (int i = 0; i < wordFamilies.size(); i++) {
            WordFamily<String> current = wordFamilies.get(i);
            if (current.size() > largestFamily.size()) {
                largestFamily = current;
            }
        }
        return largestFamily;
    }

    public void updateDisplayedPattern(WordFamily<String> chosenFamily) {
        this.displayedPattern = chosenFamily.getPattern();
    }

    public boolean isValidWordLength(int wordLength) {
        for (String word : this.possibleWords) {
            if (word.length() == wordLength) {
                return true;
            }
        }
        return false;
    }

}
