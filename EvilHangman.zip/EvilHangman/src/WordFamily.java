import java.util.ArrayList;

public class WordFamily<String> extends ArrayList<String> {
    private Pattern<String> pattern;

    public WordFamily(Pattern<String> pattern) {
        super();
        this.pattern = pattern;
    }

    public Pattern<String> getPattern() {
        return this.pattern;
    }

    public boolean patternMatches(Pattern pattern) {
        return this.pattern.equals(pattern);
    }
}
